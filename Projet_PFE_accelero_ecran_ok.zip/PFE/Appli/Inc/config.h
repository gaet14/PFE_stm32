/*
 * config.h

 *
 *  Created on: 31 mars 2016
 *      Author: Nirgal
 */

#ifndef CONFIG_H_
#define CONFIG_H_
#include "stm32f4xx_hal.h"


//Liste des modules utilisant le p�riph�rique UART/USART
#define USE_UART				1

//Module Bluetooth
#define USE_BLUETOOTH			1

//Module ILI9341
#define USE_SCREEN			1

//Module tactile de l'écran ili9341
#define TOUCH_SCREEN			1

//Module texture de l'écran ili9341
#define USE_FONT11x18           1

//Module accelerometre
#define USE_ACCELEROMETER 		1

//Pas fait encore
#define USE_PWM					0

//Pour utiliser le PWM du PCB
#define USE_PWM_PCB				1

//Liste des modules utilisant le p�riph�rique I2C
#define USE_I2C				1
//#endif
#define I2C_TIMEOUT				5	//ms

// Si I2C1_ON_PB8_PB9 = 0 => I2C1 sur Pin 6/Pin 7
#define I2C1_ON_PB8_PB9			0



//Liste des modules utilisant le p�riph�rique SPI
#define USE_SPI				1

/** Si SPI1_ON_PB3_PB4_PB5_PA4 = 0
	SPI1 GPIO Default Configuration
    PA5     ------> SPI1_SCK
    PA6     ------> SPI1_MISO
    PA7     ------> SPI1_MOSI
    PA15     ------> SPI1_NSS
    **/
#define SPI1_ON_PB3_PB4_PB5_PA4			0

/** Si SPI2_ON_PB9_PB10_PB14_PC3 = 0
	SPI2 GPIO Configuration
    PB13     ------> SPI1_SCK
    PC2     ------> SPI1_MISO
    PB15     ------> SPI1_MOSI
    PB12     ------> SPI1_NSS
    **/
#define SPI2_ON_PB9_PB10_PB14_PC3	    0

// Si on active le bouton du PCB
#define BOUTONS_PCB 1

//Si on active le bouton bleu de la discovery
#define BOUTON_DISCOVERY 1

//Si on active l'encodeur présent sur le PCB
#define ENCODEUR_PCB 1

#endif /* CONFIG_H_ */
