/*
 * encodeur_rotatif.h
 *
 *  Created on: Jan 7, 2022
 *      Author: hugol
 */

#ifndef BSP_ENCODEUR_ROTATIF_H_
#define BSP_ENCODEUR_ROTATIF_H_

void encodeur_PCB_Init(void);
void readRotaryA(void);
void readRotaryB(void);
uint8_t getCounter(void);

#endif /* BSP_ENCODEUR_ROTATIF_H_ */
