/*
 * bluetooth.c
 *
 *  Created on: Dec 9, 2021
 *      Author: gaet_
 */

#include "../../Appli/Inc/config.h"

#if USE_BLUETOOTH
#include "stm32f4_uart.h"
#include "bluetooth.h"
#include <display.h>
#include "tft_ili9341/stm32f1_ili9341.h"

uint8_t buffer;

void bluetooth_init(USART_TypeDef * USARTx, uint8_t *pData, uint16_t Size){
	// fonction d'interrruption pour allumer les leds en bluetooth
	BSP_UART_Receive_IT(USARTx, pData, Size);
	ILI9341_Fill(ILI9341_COLOR_WHITE);
	ILI9341_Puts(0,0, "Envoyer r,g,b,o ou 0", &Font_11x18, ILI9341_COLOR_RED, ILI9341_COLOR_WHITE);
	ILI9341_Puts(0,20, "pour allumer/eteindre les led", &Font_11x18, ILI9341_COLOR_RED, ILI9341_COLOR_WHITE);
	ILI9341_Puts(20,180, "Rouge", &Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_WHITE);
	ILI9341_Puts(90,180, "Green", &Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_WHITE);
	ILI9341_Puts(165,180, "Orange", &Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_WHITE);
	ILI9341_Puts(255,180, "Blue", &Font_11x18, ILI9341_COLOR_BLACK, ILI9341_COLOR_WHITE);
	Display_icon_led_black_red();
	Display_icon_led_black_green();
	Display_icon_led_black_orange();
	Display_icon_led_black_blue();
	Display_back_icon();
}

void bluetooth_deInit(USART_TypeDef * USARTx){
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, 0);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, 0);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, 0);
	BSP_UART_abort_Receive_IT(USART2);
}

void bluetooth_demo(uint8_t *buff){

	switch(buff[0]){
		case 'r' :
			Display_icon_led_red();
			break;
		case 'g' :
			Display_icon_led_green();
			break;
		case 'o' :
			Display_icon_led_orange();
			break;
		case 'b' :
			Display_icon_led_blue();
			break;
		case '0' :
			Display_icon_led_black_red();
			Display_icon_led_black_green();
			Display_icon_led_black_orange();
			Display_icon_led_black_blue();
			break;
		case '1' :
			Display_icon_led_red();
			Display_icon_led_green();
			Display_icon_led_orange();
			Display_icon_led_blue();
			break;
	}
}

#endif
