/*
 * stm32f4_adc.h
 *
 *  Created on: Oct 15, 2021
 *      Author: eloid
 */

#ifndef BSP_STM32F4_ADC_H_
#define BSP_STM32F4_ADC_H_

void adc_init(void);

#endif /* BSP_STM32F4_ADC_H_ */
