/*
 * bouton.h
 *
 *  Created on: 7 janv. 2022
 *      Author: hugol
 */

#ifndef BSP_BOUTON_H_
#define BSP_BOUTON_H_

void bouton_Bleu_Init(void);
void bouton_PCB_Init(void);

void bouton_demo(void);

#endif /* BSP_BOUTON_H_ */
