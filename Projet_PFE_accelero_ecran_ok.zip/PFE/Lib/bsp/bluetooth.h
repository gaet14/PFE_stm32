/*
 * bluetooth.h
 *
 *  Created on: Dec 9, 2021
 *      Author: gaet_
 */

#ifndef BSP_BLUETOOTH_H_
#define BSP_BLUETOOTH_H_

void bluetooth_init(USART_TypeDef * USARTx, uint8_t *pData, uint16_t Size);
void bluetooth_demo(uint8_t *buff);
void bluetooth_deInit(USART_TypeDef * USARTx);

#endif /* BSP_BLUETOOTH_H_ */
