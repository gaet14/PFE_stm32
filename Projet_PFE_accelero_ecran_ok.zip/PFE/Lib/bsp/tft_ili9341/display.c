#include <display.h>
#include "tft_ili9341/stm32f1_ili9341.h"
#include "icons_included.h"
#include "ironman.h"

void Display_Round_Icon_40x40(const unsigned int icon[], unsigned int x0, unsigned int y0, unsigned int r)
{
	uint64_t k = 0;

	ILI9341_DrawCircle(x0, y0, r, ILI9341_COLOR_BLUE);

	for(uint32_t j = y0 - 19; j < y0 + 21; j++)
	{
		for(uint32_t i = x0 -19; i < x0 + 21; i++)
		{
				ILI9341_DrawPixel(i, j, icon[k]);
				k++;
		}
	}
}

void Display_Square_Icon_40x40(const unsigned int icon[], unsigned int x0, unsigned int y0)
{
	uint64_t k = 0;

	for(uint32_t j = y0; j < y0 + 40; j++)
	{
		for(uint32_t i = x0; i < x0 + 40; i++)
		{
				ILI9341_DrawPixel(i, j, icon[k]);
				k++;
		}
	}
}

void Display_Menu()
{

	ILI9341_Rotate(ILI9341_Orientation_Landscape_2);

	/* Refresh the screen to black background */
	ILI9341_Fill(ILI9341_COLOR_BLACK);
	HAL_Delay(500);

	/* Counting through all the bytes of those icons */
	uint64_t k = 0;
	/* Draw border for the menu */
	ILI9341_DrawRectangle(ILI9341_COLOR_YELLOW, 0, 0, 310, 230);

    /* Write something */
	ILI9341_Puts(0,0, "Choissisez un programme", &Font_11x18, ILI9341_COLOR_RED, ILI9341_COLOR_WHITE);

	/* Battery Icon in the top right corner */
    for(uint32_t j = 10; j < 20; j++) {
    	for(uint32_t i = 280; i < 300; i++) {
				ILI9341_DrawPixel(i, j, battery_icon[k]);
				k++;
			}
	}

    Display_Round_Icon_40x40(home_icon_40x40, 59, 79, 40);
    Display_Round_Icon_40x40(led_icon_default_40x40, 159, 79, 40);
    Display_Round_Icon_40x40(note_icon_40x40, 259, 79, 40);
    Display_Round_Icon_40x40(game_icon_40x40, 59, 179, 40);
    Display_Round_Icon_40x40(accelero_icon_40x40, 159, 179, 40);
    Display_Round_Icon_40x40(bluetooth_icon_40x40, 259, 179, 40);


	CS_OFF;
}

void Display_back_icon(){
	Display_Square_Icon_40x40(back_icon_40x40, 280, 200);
}

void Display_icon_led_red(){
	Display_Round_Icon_40x40(led_icon_Red_40x40, 40, 120,40);
	ILI9341_DrawCircle(40, 120,40, ILI9341_COLOR_RED);

}

void Display_icon_led_green(){
	Display_Round_Icon_40x40(led_icon_Green_40x40, 120, 120,40);
	ILI9341_DrawCircle(120, 120,40, ILI9341_COLOR_GREEN);
}

void Display_icon_led_orange(){
	Display_Round_Icon_40x40(led_icon_Orange_40x40, 200, 120,40);
	ILI9341_DrawCircle(200, 120,40, ILI9341_COLOR_ORANGE);
}

void Display_icon_led_blue(){
	Display_Round_Icon_40x40(led_icon_Blue_40x40, 280, 120,40);
	ILI9341_DrawCircle(280, 120, 40, ILI9341_COLOR_BLUE);
}

void Display_icon_led_black_red(){
	Display_Round_Icon_40x40(led_icon_Black_40x40, 40, 120,40);
}

void Display_icon_led_black_green(){
	Display_Round_Icon_40x40(led_icon_Black_40x40, 120, 120,40);
}

void Display_icon_led_black_orange(){
	Display_Round_Icon_40x40(led_icon_Black_40x40, 200, 120,40);
}

void Display_icon_led_black_blue(){
	Display_Round_Icon_40x40(led_icon_Black_40x40, 280, 120,40);
}


void Display_selection(uint8_t selecX){
	switch(selecX){
		case  1 :
			ILI9341_DrawCircle(59,79,40,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,79,41,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,79,42,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,79,43,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,79,44,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,79,45,ILI9341_COLOR_RED);
			break;
		case 2 :
			ILI9341_DrawCircle(159, 79, 40,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159, 79, 41,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159, 79, 42,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159, 79, 43,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159, 79, 44,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159, 79, 45,ILI9341_COLOR_RED);
			break;
		case  3 :
			ILI9341_DrawCircle(259,79,40,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,79,41,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,79,42,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,79,43,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,79,44,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,79,45,ILI9341_COLOR_RED);
			break;
		case 4 :
			ILI9341_DrawCircle(59,179,40,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,179,41,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,179,42,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,179,43,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,179,44,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(59,179,45,ILI9341_COLOR_RED);
			break;
		case  5 :
			ILI9341_DrawCircle(159,179,40,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159,179,41,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159,179,42,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159,179,43,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159,179,44,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(159,179,45,ILI9341_COLOR_RED);
			break;
		case 6 :
			ILI9341_DrawCircle(259,179,40,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,179,41,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,179,42,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,179,43,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,179,44,ILI9341_COLOR_RED);
			ILI9341_DrawCircle(259,179,45,ILI9341_COLOR_RED);
			break;
	}
}


void Display_selection_suppression(uint8_t selecX){
	switch(selecX){
		case  1 :
			ILI9341_DrawCircle(59,79,40,ILI9341_COLOR_BLUE);
			ILI9341_DrawCircle(59,79,41,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(59,79,42,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(59,79,43,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(59,79,44,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(59,79,45,ILI9341_COLOR_BLACK);
			break;
		case 2 :
			ILI9341_DrawCircle(159, 79, 40,ILI9341_COLOR_BLUE);
			ILI9341_DrawCircle(159, 79, 41,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(159, 79, 42,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(159, 79, 43,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(159, 79, 44,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(159, 79, 45,ILI9341_COLOR_BLACK);
			break;
		case  3 :
			ILI9341_DrawCircle(259,79,40,ILI9341_COLOR_BLUE);
			ILI9341_DrawCircle(259,79,41,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(259,79,42,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(259,79,43,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(259,79,44,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(259,79,45,ILI9341_COLOR_BLACK);
			break;
		case 4 :
			ILI9341_DrawCircle(59,179,40,ILI9341_COLOR_BLUE);
			ILI9341_DrawCircle(59,179,41,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(59,179,42,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(59,179,43,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(59,179,44,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(59,179,45,ILI9341_COLOR_BLACK);
			break;
		case  5 :
			ILI9341_DrawCircle(159,179,40,ILI9341_COLOR_BLUE);
			ILI9341_DrawCircle(159,179,41,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(159,179,42,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(159,179,43,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(159,179,44,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(159,179,45,ILI9341_COLOR_BLACK);
			break;
		case 6 :
			ILI9341_DrawCircle(259,179,40,ILI9341_COLOR_BLUE);
			ILI9341_DrawCircle(259,179,41,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(259,179,42,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(259,179,43,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(259,179,44,ILI9341_COLOR_BLACK);
			ILI9341_DrawCircle(259,179,45,ILI9341_COLOR_BLACK);
			break;
	}
}
/*

void Display_Picture()
{
	ILI9341_Rotate(ILI9341_Orientation_Landscape_2);

	uint64_t k = 0;
	for(uint32_t i = 0; i < 240; i++)
	{
		for(uint32_t j = 320; j > 0; j--)
		{
			ILI9341_DrawPixel(i, j, ironman[k]);
			k++;
		}
	}
}

void Display_Text()
{
	ILI9341_Fill(ILI9341_COLOR_BLACK);
	HAL_Delay(500);

	ILI9341_DrawRectangle(ILI9341_COLOR_YELLOW, 10, 30, 310, 230);

	ILI9341_Draw_String(20, 40, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK, "Hello User!", 2);

	ILI9341_Draw_String(20, 60, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK, "This is the test for TFT LCD!", 2);

	ILI9341_Draw_String(20, 80, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK, "For more information, please visit:", 2);

	ILI9341_Draw_String(20, 100, ILI9341_COLOR_WHITE, ILI9341_COLOR_BLACK, "    aweirdolife.wordpress.com    ", 2);

	Display_Square_Icon_40x40(back_icon_40x40, 0, 200);
}

void Display_Color_Picture()
{
	for (uint16_t i = 0; i < 280; i++)
	{
		for (uint16_t j = 0; j < 320; j++)
		{
			ILI9341_Draw_Double_Pixel(j, i, ironman[(640 * i) + j * 2], ironman[(640 * i) + j * 2 + 1]);
		}
	}

	Display_Square_Icon_40x40(back_icon_40x40, 0, 200);
}
*/
