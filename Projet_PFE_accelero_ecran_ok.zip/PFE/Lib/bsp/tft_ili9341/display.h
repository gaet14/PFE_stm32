#include "stm32f4xx_hal.h"
#include <stdlib.h>
#include "main.h"
#include "tft_ili9341/stm32f1_ili9341.h"

void Display_Menu(void);
void Display_Text(void);
void Display_Picture(void);
void Display_Color_Picture(void);
void Display_selection(uint8_t selecX);
void Display_selection_suppression(uint8_t selecX);
void Display_back_icon();

void Display_back_icon();
void Display_icon_led_red();
void Display_icon_led_green();
void Display_icon_led_orange();
void Display_icon_led_blue();
void Display_icon_led_black_red();
void Display_icon_led_black_green();
void Display_icon_led_black_orange();
void Display_icon_led_black_blue();
