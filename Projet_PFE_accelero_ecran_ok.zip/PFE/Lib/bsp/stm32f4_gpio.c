// TODO : Alternate Mode


/** \file GPIO.c
   * \brief implementation des fonctions d'initialisation des GPIO et les fonctions d'usage.
   * \author Florent CHARRUAUD
   * \date 23 janvier 2014
   */
/* Includes ------------------------------------------------------------------*/
#include "stm32f4_gpio.h"
#include "../../Appli/Inc/main.h"
#include "stm32f4xx_hal.h"

/*
 * Ce module logiciel a pour but de simplifier l'utilisation des fonctions HAL_GPIO_...
 *
 * Attention � penser � appeler au moins une fois, lors de l'initialisation, la fonction :
 * 		BSP_GPIO_Enable();
 *
 * Initialiser une broche en entr�e (exemple) :
 * 		BSP_GPIO_PinCfg(GPIOA,GPIO_PIN_0,GPIO_MODE_INPUT,GPIO_NO_PULL,GPIO_SPEED_HIGH);
 * 			variante tirage pour appliquer des tirages haut ou bas : GPIO_PULLUP, GPIO_PULLDOWN
 * 			variante mode   pour utiliser une "alternate function" en entr�e : GPIO_MODE_AF_INPUT
 *
 * Initialiser une broche en sortie (exemple) :
 * 		BSP_GPIO_PinCfg(GPIOA,GPIO_PIN_0,GPIO_MODE_OUTPUT_PP,GPIO_PULLUP,GPIO_SPEED_HIGH);
 * 			variante pour utiliser une "alternate function" en sortie : GPIO_MODE_AF_OD ou GPIO_MODE_AF_PP
 *
 *
 * Pour manipuler les broches ainsi configur�es :
 * 		b = HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_0,GPIO_PIN_SET);	-> renvoie 0 ou 1... selon l'�tat de la broche en entr�e
 * 		HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_SET);		-> �crit 0 ou 1 sur la broche en sortie
 * 		HAL_GPIO_TogglePin(GPIOA,GPIO_PIN_0);					-> inverse l'�tat de la broche en sortie (0 <-> 1)
 *
 */



/* Private functions ---------------------------------------------------------*/
/**
 * @brief	Configuration des entrees/sorties des broches du microcontroleur.
 * @func	void BSP_GPIO_Enable(void)
 * @post	Activation des horloges des peripheriques GPIO
 */
void BSP_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	  /* GPIO Ports Clock Enable */
	  __HAL_RCC_GPIOE_CLK_ENABLE();
	  __HAL_RCC_GPIOC_CLK_ENABLE();
	  __HAL_RCC_GPIOH_CLK_ENABLE();
	  __HAL_RCC_GPIOA_CLK_ENABLE();
	  __HAL_RCC_GPIOB_CLK_ENABLE();
	  __HAL_RCC_GPIOD_CLK_ENABLE();

	  /*Configure GPIO pin Output Level */
	  HAL_GPIO_WritePin(CS_I2C_SPI_GPIO_Port, CS_I2C_SPI_Pin, GPIO_PIN_RESET);

	  /*Configure GPIO pin Output Level */
	  HAL_GPIO_WritePin(OTG_FS_PowerSwitchOn_GPIO_Port, OTG_FS_PowerSwitchOn_Pin, GPIO_PIN_SET);

	  /*Configure GPIO pin Output Level */
	  HAL_GPIO_WritePin(GPIOD, LD4_Pin|LD3_Pin|LD5_Pin|LD6_Pin
	                          |Audio_RST_Pin, GPIO_PIN_RESET);

	  /*Configure GPIO pin : CS_I2C_SPI_Pin */
	  GPIO_InitStruct.Pin = CS_I2C_SPI_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(CS_I2C_SPI_GPIO_Port, &GPIO_InitStruct);

	  /*Configure GPIO pin : OTG_FS_PowerSwitchOn_Pin */
	  GPIO_InitStruct.Pin = OTG_FS_PowerSwitchOn_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(OTG_FS_PowerSwitchOn_GPIO_Port, &GPIO_InitStruct);

	  /*Configure GPIO pin : PDM_OUT_Pin */
	  GPIO_InitStruct.Pin = PDM_OUT_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
	  HAL_GPIO_Init(PDM_OUT_GPIO_Port, &GPIO_InitStruct);

	  /*Configure GPIO pin : B1_Pin */
	  GPIO_InitStruct.Pin = B1_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

	  /*Configure GPIO pin : I2S3_WS_Pin */
	  GPIO_InitStruct.Pin = I2S3_WS_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  GPIO_InitStruct.Alternate = GPIO_AF6_SPI3;
	  HAL_GPIO_Init(I2S3_WS_GPIO_Port, &GPIO_InitStruct);

	  /*Configure GPIO pins : SPI1_SCK_Pin SPI1_MISO_Pin SPI1_MOSI_Pin */
	  GPIO_InitStruct.Pin = SPI1_SCK_Pin|SPI1_MISO_Pin|SPI1_MOSI_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
	  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	  /*Configure GPIO pin : BOOT1_Pin */
	  GPIO_InitStruct.Pin = BOOT1_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  HAL_GPIO_Init(BOOT1_GPIO_Port, &GPIO_InitStruct);

	  /*Configure GPIO pins : LD4_Pin LD3_Pin LD5_Pin LD6_Pin
	                           Audio_RST_Pin */
	  GPIO_InitStruct.Pin = LD4_Pin|LD3_Pin|LD5_Pin|LD6_Pin
	                          |Audio_RST_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

	  /*Configure GPIO pins : I2S3_MCK_Pin I2S3_SCK_Pin I2S3_SD_Pin */
	  GPIO_InitStruct.Pin = I2S3_MCK_Pin|I2S3_SCK_Pin|I2S3_SD_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  GPIO_InitStruct.Alternate = GPIO_AF6_SPI3;
	  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	  /*Configure GPIO pin : OTG_FS_OverCurrent_Pin */
	  GPIO_InitStruct.Pin = OTG_FS_OverCurrent_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  HAL_GPIO_Init(OTG_FS_OverCurrent_GPIO_Port, &GPIO_InitStruct);

	  /*Configure GPIO pin : MEMS_INT2_Pin */
	  GPIO_InitStruct.Pin = MEMS_INT2_Pin;
	  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  HAL_GPIO_Init(MEMS_INT2_GPIO_Port, &GPIO_InitStruct);

	}


/**
 * @brief Fonction generale permettant de configurer une broche
 * @func void BSP_GPIO_PinCfg(GPIO_TypeDef * GPIOx, uint32_t GPIO_Pin, uint32_t GPIO_Mode, uint32_t GPIO_Pull, uint32_t GPIO_Speed, uint32_t GPIO_Alternate)
 * @param GPIOx : peut-etre GPIOA-G
 * @param GPIO_Pin : GPIO_PIN_X avec X correspondant a la (ou les) broche souhaitee
 * @param GPIO_Mode : GPIO_MODE_INPUT, GPIO_MODE_OUTPUT_PP, GPIO_MODE_OUTPUT_OD, GPIO_MODE_AF_PP, GPIO_MODE_AF_OD ou GPIO_MODE_ANALOG
 * @param GPIO_Pull : GPIO_NOPULL, GPIO_PULLUP, GPIO_PULLDOWN
 * @param GPIO_Speed : GPIO_SPEED_LOW (2MHz), GPIO_SPEED_MEDIUM (25MHz), GPIO_SPEED_HIGH (100MHz)
  */
void BSP_GPIO_PinCfg(GPIO_TypeDef * GPIOx, uint32_t GPIO_Pin, uint32_t GPIO_Mode, uint32_t GPIO_Pull, uint32_t GPIO_Speed)
{
	GPIO_InitTypeDef GPIO_InitStructure;					//Structure contenant les arguments de la fonction GPIO_Init
	GPIO_InitStructure.Pin = GPIO_Pin;
	GPIO_InitStructure.Mode = GPIO_Mode;
	GPIO_InitStructure.Pull = GPIO_Pull;
	GPIO_InitStructure.Speed = GPIO_Speed;
	HAL_GPIO_Init(GPIOx, &GPIO_InitStructure);
}



