/*
 * encodeur_rotatif.c
 *
 *  Created on: Jan 7, 2022
 *      Author: hugol
 */

/*
 * !!! DANGER !!!
 * Vérification de l'EXTI
 * Ce dernier est identique aux deux poussoirs en PE12 et PE13
 * Là il faut regarder EXTI 14 et EXTI 15 mais tout doit être dans le fichier stm32f4xx_it.c
 *
 * Il faut aussi créer des var dans le fichier config.h et #if stm32f4xx_it.c
 */
#include "config.h"

#if ENCODEUR_PCB
#include "encodeur.h"
#include "stdio.h"
#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_gpio.h"
#include "stdbool.h"
#include "display.h"


static GPIO_InitTypeDef GPIO_InitStruct = {0};
static uint8_t counter=0;

#define READ_PIN_A HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_14)
#define READ_PIN_B HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_15)


void encodeur_PCB_Init(void)
{
	__HAL_RCC_GPIOC_CLK_ENABLE();
  GPIO_InitStruct.Pin = GPIO_PIN_14 | GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/*
 * Ce code permet d'éviter les IT sur A et B mais uniquement sur A.
 */

void readRotaryA(void)
{

	if(READ_PIN_B)
	{
		if(counter>255){
			counter = 0;
		}
		else{
		counter++;
		}
	}else
	{
		if(counter<0){
			counter = 255;
		}else{
			counter --;
		}

	}

}
//https://rco.fr.nf/index.php/2016/07/06/codeurs-et-robotique/
// OU https://arduino.blaisepascal.fr/les-codeurs-incrementaux/
void readRotaryB(void)
{
	if(READ_PIN_A)
	{
		if(counter<0){
			counter = 255;
		}else{
			counter --;
		}
	}
	else{
		if(counter>255){
			counter = 0;
		}
		else{
			counter++;
		}
	}
}

uint8_t getCounter(void)
{
	return counter;
}


#endif
