/*
 * joystick_I2C.h
 *
 *  Created on: 15 oct. 2021
 *      Author: eloid
 */

#ifndef BSP_JOYSTICK_I2C_H_
#define BSP_JOYSTICK_I2C_H_



#endif /* BSP_JOYSTICK_I2C_H_ */
