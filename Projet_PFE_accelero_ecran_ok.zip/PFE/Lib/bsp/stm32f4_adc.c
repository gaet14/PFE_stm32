/*
 * stm32f4_adc.c
 *
 *  Created on: Oct 15, 2021
 *      Author: eloid
 */
#include "../../Appli/Inc/config.h"

#if USE_ADC
#include"stm32f4_adc.h"
#include "stm32f4xx_hal.h"
#include "stm32f4_gpio.h"

void adc_init(void)
{
	BSP_GPIO_Init();

	#if USE_AN0
		BSP_GPIO_PinCfg(GPIOA, GPIO_PIN_1, PIO_MODE_ANALOG, GPIO_NOPULL, GPIO_SPEED_FREQ_MEDIUM);
	#endif
	#if USE_AN1
		BSP_GPIO_PinCfg(GPIOA, GPIO_PIN_4, PIO_MODE_ANALOG, GPIO_NOPULL, GPIO_SPEED_FREQ_MEDIUM);
	#endif
	#if USE_AN2
		BSP_GPIO_PinCf(GPIOC, GPIO_PIN_1, PIO_MODE_ANALOG, GPIO_NOPULL, GPIO_SPEED_FREQ_MEDIUM);
	#endif
	#if USE_AN3
		BSP_GPIO_PinCfg(GPIOC, GPIO_PIN_2, PIO_MODE_ANALOG, GPIO_NOPULL, GPIO_SPEED_FREQ_MEDIUM);
	#endif

}

#endif
