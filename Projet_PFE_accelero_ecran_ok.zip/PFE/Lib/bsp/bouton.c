/*
 * bouton.c
 *
 *  Created on: 7 janv. 2022
 *      Author: hugol
 *
 *      Les appels des IT se font dans le fichier "Appli/Src/stm32f4xx_it.c"
 *		Fonction : EXTI15_10_IRQHandler pour les boutons du PCB et EXTI0_IRQHandler pour le bouton bleu
 *		Dans cette fonction les IT sur les pin GPIO de 10 à 15 sont répertoriées.
 */
#include "config.h"
#include "stdio.h"
#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_gpio.h"
#include "bouton.h"



static GPIO_InitTypeDef GPIO_InitStruct = {0};

#if BOUTON_DISCOVERY
void bouton_Bleu_Init(void)
{
	__HAL_RCC_GPIOA_CLK_ENABLE();
  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  //pull up button, if pull down ==>  GPIO_MODE_IT_FALLING
  //==> a param pour le PCB
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  HAL_NVIC_SetPriority(EXTI0_IRQn, 5, 1);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);
}

#endif

#if BOUTONS_PCB
void bouton_PCB_Init(void)
{
	__HAL_RCC_GPIOE_CLK_ENABLE();
  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_12 | GPIO_PIN_13;
  //pull up button, if pull down ==>  GPIO_MODE_IT_FALLING
  //==> a param pour le PCB
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  //HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
  //HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/*
 * Cette démo a pour but de montrer le fonctionnement
 */

void bouton_demo(void)
{
	  //Initialisation des boutons
	  bouton_PCB_Init();

	  //Initialisation des LEDS
	  __HAL_RCC_GPIOD_CLK_ENABLE();
	  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12|GPIO_PIN_14, GPIO_PIN_RESET);
	  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_14;
	  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	  GPIO_InitStruct.Pull = GPIO_NOPULL;
	  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
	  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12|GPIO_PIN_14, GPIO_PIN_RESET);
	  printf("Init terminé\n");
}
#endif
